// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_OC_INFO_CCH_MAX ( 1024 )




#define n_oc_info_zero( p ) n_memory_zero( p, sizeof( n_oc_info ) )

u32
n_oc_info_color( void )
{

	u32 c = oc_color.bg;
	if ( oc.find_mode == N_ORANGECAT_FIND_MODE_NONE )
	{
		c = oc_color.info_bg_1;
	} else
	if ( oc.find_mode == N_ORANGECAT_FIND_MODE_NAME )
	{
		c = oc_color.info_bg_1;
	} else
	if ( oc.find_mode == N_ORANGECAT_FIND_MODE_TEXT )
	{
		c = oc_color.info_bg_2;
	}


	return c;
}

void
n_oc_info_flush( u32 *color_fg, u32 *color_bg, u32 *color )
{

	u32 c  = n_oc_info_color();
	u32 fg = c;
	u32 bg = oc_color.bg;

	if ( oc.dwm_onoff )
	{
		bg = n_bmp_blend_pixel( bg, fg, 0.75 );
		c  = oc_color.bg;
	}

	n_bmp_flush( &game.bmp, c );


	if ( color_fg != NULL ) { (*color_fg) = fg; }
	if ( color_bg != NULL ) { (*color_bg) = bg; }
	if ( color    != NULL ) { (*color   ) =  c; }


	return;
}

void
n_oc_info_fade_go( n_oc_info *p, COLORREF color )
{

	if ( p == NULL ) { return; }


	n_bmp_fade_go( &p->fade, color );

	if ( p->fade_timer == 0 ) { p->fade_timer = n_win_timer_id_get(); }
	n_win_timer_init( game.hwnd, p->fade_timer, 33 );


	return;
}

COLORREF 
n_oc_info_fade_color( n_oc_info *p )
{

	COLORREF color = 0;

	if ( p->txtbox[ 0 ].ime_onoff )
	{
		color = p->txtbox[ 0 ].color_back_selected;
	} else {
		color = n_bmp_pal2rgb( n_oc_info_color() );
	}


	return color;
}

void
n_oc_info_scaling( n_oc_info *p )
{

	int i = 0;
	while( 1 )
	{

		n_win_txtbox_scaling( &p->txtbox[ i ] );


		i++;
		if ( i >= N_OC_INFO_TXTBOX_MAX ) { break; }
	}

}

bool
n_oc_info_input_is_hovered( n_oc_info *p )
{

	bool ret = false;


	int i = 0;
	while( 1 )
	{

		if ( p->txtbox[ i ].hwnd == n_win_cursor2hwnd_relative( game.hwnd ) )
		{
			ret = true;

			break;
		}

		i++;
		if ( i >= N_OC_INFO_TXTBOX_MAX ) { break; }
	}


	return ret;
}

void
n_oc_info_input_refresh( n_oc_info *p )
{

	// [x] : Win95 : needed at resizing

	int i = 0;
	while( 1 )
	{

		n_win_txtbox_refresh( &p->txtbox[ i ] );

		i++;
		if ( i >= N_OC_INFO_TXTBOX_MAX ) { break; }
	}


	return;
}

void
n_oc_info_input_focus_off( n_oc_info *p )
{

	int i = 1;
	while( 1 )
	{

		n_win_txtbox_unselect( &info.txtbox[ i ] );

		i++;
		if ( i >= N_OC_INFO_TXTBOX_MAX ) { break; }
	}


	return;
}

void
n_oc_info_input_draw( n_oc_info *p, int index )
{

	// [!] : for smooth transition


	if ( p->visible[ index ] == false ) { return; }


	n_win_txtbox *txtbox = &p->txtbox[ index ];

	s32  x = p->edit_x [ index ];
	s32  y = p->edit_y [ index ];
	s32 sx = p->edit_sx[ index ];
	s32 sy = p->edit_sy[ index ];


	HDC hdc        = GetDC( txtbox->hwnd );
	HDC hdc_compat = CreateCompatibleDC( hdc );

	HBITMAP hbmp;
	n_bmp    bmp;
	n_gdi_dibsection_zero( &hbmp, &bmp );
	n_gdi_dibsection_init( &hbmp, &bmp, txtbox->hwnd, hdc_compat, sx,sy );


//n_posix_debug_literal( " %d ", IsWindowEnabled( txtbox->hwnd ) );

	if ( oc.dwm_onoff )
	{
		n_bmp_flush( &bmp, 0 );
	} else {
		n_bmp_flush( &bmp, n_gdi_systemcolor( COLOR_WINDOW ) );
	}


	HBITMAP hbmp_prv = SelectObject( hdc_compat, hbmp );


	HFONT hf = SelectObject( hdc_compat, n_win_font_get( txtbox->hwnd ) );

	if ( oc.find_mode != N_ORANGECAT_FIND_MODE_NONE ) { SetFocus( txtbox->hwnd ); }

	int   p_bpp = 0;
	n_bmp p_bmp;

	if ( oc.dwm_onoff )
	{
		p_bpp = n_gdi_doublebuffer_instance.bpp; n_gdi_doublebuffer_instance.bpp = 32;

		n_bmp_alias( &n_gdi_doublebuffer_instance.bmp, &p_bmp );
		n_bmp_alias( &bmp, &n_gdi_doublebuffer_instance.bmp );
	}

	txtbox->hdc = hdc_compat;
	n_win_txtbox_draw_singleline( txtbox, 0, 0,0, txtbox->canvas_pxl_sx,txtbox->canvas_pxl_sy );

	if ( oc.dwm_onoff )
	{
		n_gdi_doublebuffer_instance.bpp = p_bpp;

		n_bmp_alias( &n_gdi_doublebuffer_instance.bmp, &bmp );
		n_bmp_alias( &p_bmp, &n_gdi_doublebuffer_instance.bmp );
	}

	SelectObject( hdc_compat, hf );


	s32  fx = 0;
	s32  fy = 0;
	s32 fsx = N_BMP_SX( &bmp );
	s32 fsy = N_BMP_SY( &bmp );

//n_bmp_flush( &bmp, n_bmp_rgb( 255,0,0 ) );

	if ( oc.dwm_onoff )
	{
		n_bmp_flush_mirror( &bmp, N_BMP_MIRROR_UPSIDE_DOWN );
	}

//if ( index == 0 ) { n_bmp_save_literal( &bmp, "ret.bmp" ); }

	n_bmp_fastcopy( &bmp, &game.bmp, fx,fy,fsx,fsy, x,y );


	SelectObject( hdc_compat, hbmp_prv );


	n_gdi_dibsection_exit( &hbmp, &bmp );

	DeleteObject( hdc_compat );
	ReleaseDC( txtbox->hwnd, hdc );


	return;
}

void
n_oc_info_exit( n_oc_info *p )
{

	n_win_simplemenu_close( n_win_simplemenu_target );


	n_win_timer_exit( game.hwnd, p->fade_timer );


	n_string_path_free( p->icon );
	n_string_path_free( p->name );


	n_bmp_free( &p->bmp );


#ifdef _WIN64

	RemoveWindowSubclass( p->txtbox[ 0 ].hwnd, n_win_subclass_txtbox_on_keydown, 0 );

#else  // #ifdef _WIN64

	WNDPROC pfunc_0 = (WNDPROC) n_win_property_get_literal( p->txtbox[ 0 ].hwnd, "n_win_subclass_txtbox_on_keydown()" );
	WNDPROC pfunc_1 = (WNDPROC) n_win_property_get_literal( p->txtbox[ 0 ].hwnd, "WM_KEYDOWN" );

	n_win_gui_subclass_set( p->txtbox[ 0 ].hwnd, pfunc_1 );
	n_win_gui_subclass_set( p->txtbox[ 0 ].hwnd, pfunc_0 );

	n_win_property_exit_literal( p->txtbox[ 0 ].hwnd, "IME" );
	n_win_property_exit_literal( p->txtbox[ 0 ].hwnd, "WM_KEYDOWN" );
	n_win_property_exit_literal( p->txtbox[ 0 ].hwnd, "n_win_subclass_txtbox_on_keydown()" );

#endif // #ifdef _WIN64


	{

		int i = 0;
		while( 1 )
		{

			if ( p->txtbox[ i ].hwnd != NULL )
			{
				n_win_stdfont_exit( &p->txtbox[ i ].hwnd, 1 );

				n_win_txtbox_exit( &p->txtbox[ i ] );
			}

			i++;
			if ( i >= N_OC_INFO_TXTBOX_MAX ) { break; }
		}

	}


	n_oc_info_zero( p );


	game.color = oc_color.bg;


	n_game_refresh_on();
	return;
}

bool
n_oc_info_go( n_oc_info *p )
{

	// Find or Rename

	bool ret = false;


	n_posix_char *str_f = n_string_path_name_new( p->name );
	n_posix_char *str_t = n_win_txtbox_selection_new( &p->txtbox[ 0 ] );
//n_posix_debug_literal( "f:%s\nt:%s", str_f,str_t );


	if ( item.view_type == N_ORANGECAT_VIEW_TYPE_PATH )
	{

		//

	} else
	if ( false == IsWindow( p->txtbox[ 0 ].hwnd ) )
	{
//n_game_hwndprintf_literal( "if ( false == IsWindow( p->txtbox[ 0 ].hwnd ) )" );

		// [!] : "str_t" will be empty when n_game_exit()

	} else
	if ( oc.find_mode )
	{
//n_posix_debug_literal( " %s ", str_t );

		if (
			( false == n_string_is_empty( str_t ) )
			&&
			( false == n_string_is_same( oc.find, str_t ) )
		)
		{

			ret = true;

			n_string_path_free( oc.find );
			oc.find = n_string_path_carboncopy( str_t );
//n_posix_debug_literal( " ret = true : %s ", oc.find );

		} else {
//n_game_hwndprintf_literal( " ret = false " );

			oc.find_mode = N_ORANGECAT_FIND_MODE_NONE;
		}

	} else
	if ( false == n_string_is_same_strict( str_f, str_t ) )
	{
//n_posix_debug_literal( "f:%s\nt:%s", str_f,str_t );

		if ( p->is_computer_on_breadcrumb )
		{

			bool b = SetComputerName( str_t );
			if ( b == 0 )
			{
				// [x] : User  : ERROR_INVALID_HANDLE(6)
			} else {
				// [x] : Admin : succeeded but a name is not renamed
			}
//n_posix_debug_literal( "%d\n%s", GetLastError(), t );

		} else
		if ( p->drive_usage != -1 )
		{

			// [x]
			//	not function when Vista or later
			//	UAC will stop renaming
			//
			//	restricted users cannot rename too
			//
			//	ERROR_ACCESS_DENIED 5L
			//
			//	"C:\" only, "C:" will not be accepted

			// [x] : DOS LABEL command
			//
			//	1 : an empty string cannot be accepted
			//	2 : process will be zombie when an empty string is set
			//
			//	"C:" only, "C:\" will not be accepted

			// [x] : WinXP or earlier : when restricted users
			//
			//	ShellExecute() returnes ERROR_FILE_NOT_FOUND 2L

			// [x] : SetVolumeLabel()
			//
			//	ERROR_MORE_DATA 234 will be returned when succeeded

			BOOL b = SetVolumeLabel( p->icon, str_t );
//n_posix_debug_literal( "%d", GetLastError() );

			if ( b )
			{

				ret = true;

			} else {

				n_posix_char *exe = n_string_path_cat( oc.exec, N_STRING_SPACE, N_APPS_OPTION_ORANGECAT, NULL );
				n_posix_char *prm = n_string_path_cat( N_ORANGECAT_OPTION_LABEL, N_STRING_SPACE, p->icon, N_STRING_SPACE, str_t, NULL );

//n_posix_debug_literal( "%s\n%s", exe, prm );

				ret = n_oc_shellexecute
				(
					n_posix_literal( "runas" ),
					exe,
					prm, //n_posix_literal( "Z: TEST" ),
					SW_HIDE
				);
				ret = n_oc_bool_toggle( ret );

				n_string_path_free( exe );
				n_string_path_free( prm );

			}

			if ( ( ret )&&( oc.view_is_computer ) )
			{

				ret = false;

				int index = n_oc_item_path2index( &item, p->icon );

				n_oc_item_sync_fast( &item, index );

			}

		} else
		if (
			( false == n_string_is_empty( str_f ) )
			&&
			( false == n_string_is_empty( str_t ) )
		)
		{

			n_posix_char *str_upper  = n_string_path_upperfolder_new( p->name );
			n_posix_char *str_rename = n_string_path_make_new( str_upper, str_t );

			ret = n_posix_rename( p->name, str_rename );

			if ( ret != 0 )
			{

				ret = false;

				n_project_dialog_info( game.hwnd, n_project_string_error );

			} else {

				ret = true;

				int index = n_oc_item_path2index( &item, p->name );


				n_posix_char *s = n_string_path_name_new( str_rename );
//n_posix_debug_literal( "%s\n%s", n_dir_name( &item.dir, index ), s );

				n_dir_mod( &item.dir, index, n_dir_path( &item.dir, index ), s );

				n_string_path_free( s );


				n_oc_item_sync_fast( &item, index );

			}

			n_string_path_free( str_rename );
			n_string_path_free( str_upper  );

		}

	} // if ( false == n_string_is_same_strict( str_f, str_t ) )


	int i = 0;
	while( 1 )
	{//break;

		if ( IsWindow( p->txtbox[ i ].hwnd ) )
		{
			n_oc_info_input_draw( p, i );
			ShowWindow( p->txtbox[ i ].hwnd, SW_HIDE );
		}

		i++;
		if ( i >= N_OC_INFO_TXTBOX_MAX ) { break; }
	}


	n_string_path_free( str_f );
	n_string_path_free( str_t );


	return ret;
}

s32
n_oc_info_draw_calc( n_oc_info *p, s32 border, s32 gap, int line_max )
{

	s32 sy = 0;


	s32 y = 0;
	int i = 0;
	while( 1 )
	{//break

		if ( ( p->drive_label_is_empty )&&( i == 0 ) )
		{
			//
		} else {
			if ( n_string_is_empty( n_txt_get( &p->txtbox[ i ].txt, 0 ) ) ) { break; }
		}


		n_win_stdsize_text( p->txtbox[ i ].hwnd, n_posix_literal( "a" ), NULL, &sy );

		if ( i == 0 )
		{
			sy = sy + ( border * 4 );
		}

		y += sy;

		if ( p->drive_usage == -1 )
		{
			if ( i == 0 ) { y += gap * 4; } else
			if ( i == 1 ) { y += gap * 4; } else
			if ( i == 4 ) { y += gap * 4; }
		} else {
			if ( i == 0 ) { y += gap * 4; } else
			if ( i == 1 ) { y += gap * 4; }
		}

		i++;
		if ( i >= line_max ) { break; }
	}


	return y;
}

void
n_oc_info_draw( n_oc_info *p )
{

	s32 m   = oc.unit_rect * oc.unit_scal;
	s32 mm  = m * 2;
	s32 bdr = 0; n_win_stdsize( game.hwnd, NULL, NULL, &bdr );
	s32 gap = bdr * 2;


	{

		// Background

		s32  u = oc.unit / 2;
		s32  x = m;
		s32  y = m;
		s32 sx = game.sx - mm;
		s32 sy = game.sy - mm;

		n_oc_frame( &game.bmp, x,y,sx,sy, m,-u, p->bg,p->bg );

	}


	int line_max = N_OC_INFO_TXTBOX_MAX;


	s32 ty = n_game_centering( game.sy, oc.unit );
	if ( oc.find_mode == N_ORANGECAT_FIND_MODE_NONE )
	{

		s32 y = n_oc_info_draw_calc( p, bdr, gap, line_max );

		// [x] : false != n_string_is_empty() : not working

		bool is_folder = n_string_is_empty( n_txt_get( &p->txtbox[ 3 ].txt, 0 ) );
		bool is_no_ver = n_string_is_empty( n_txt_get( &p->txtbox[ 5 ].txt, 0 ) );

		s32 icon_sy = N_BMP_SY( &p->bmp ) + gap + ( gap * 2 );

//n_game_hwndprintf_literal( " %d %d %d ", ( y + icon_sy ) ), ( game.sy - mm ), gap );

//n_game_hwndprintf_literal( " 1 " );

		if (
			( y > ( game.sy - mm ) )
			||
			(
				( is_folder )
				&&
				( ( y + ( icon_sy + m ) ) > ( game.sy - mm ) )
			)
			||
			(
				( p->drive_usage != -1 )
				&&
				( ( y + ( icon_sy + m ) ) > ( game.sy - mm ) )
			)
			||
			(
				( is_folder == false )
				&&
				( is_no_ver != false )
				&&
				( ( y + ( icon_sy + 0 ) ) > ( game.sy - mm ) )
			)
			||
			(
				( is_folder == false )
				&&
				( is_no_ver == false )
				&&
				( ( y + ( icon_sy + m ) ) > ( game.sy - mm ) )
			)
		)
		{
//n_game_hwndprintf_literal( " 2 " );

			if (
				( is_folder == false )
				&&
				( is_no_ver == false )
			)
			{
//n_game_hwndprintf_literal( " 2 - 1 " );
				line_max = 5;
				y = n_oc_info_draw_calc( p, bdr, gap, line_max ) - icon_sy;
			}


			if ( ( y + ( icon_sy + m ) ) > ( game.sy - mm ) )
			{
//n_game_hwndprintf_literal( " 2 - 2 " );
				line_max = 2;
				if ( ( ty - icon_sy ) < m ) { line_max = 1; }
//n_game_hwndprintf_literal( " %d %d : %d ", ty - icon_sy, m, line_max );
				y = n_oc_info_draw_calc( p, bdr, gap, line_max ) - icon_sy;
			} else
			if ( ( n_game_centering( game.sy, y ) - icon_sy ) <= m )
			{
//n_game_hwndprintf_literal( " 2 - 3 " );
				line_max = 2;
				if ( ( ty - icon_sy ) < m ) { line_max = 1; }
//n_game_hwndprintf_literal( " %d %d : %d ", ty - icon_sy, m, line_max );
				y = n_oc_info_draw_calc( p, bdr, gap, line_max ) - icon_sy;
			}

		} else {
//n_game_hwndprintf_literal( " 3 " );

			y -= icon_sy;

			if ( is_no_ver == false )
			{
//n_game_hwndprintf_literal( " 4 " );

				if ( ( y + ( icon_sy + m ) ) > ( game.sy - mm ) )
				{
					line_max = 5;
					y = n_oc_info_draw_calc( p, bdr, gap, line_max ) - icon_sy;
				}

			}

		}

		ty = n_game_centering( game.sy, y );

		if ( p->drive_usage != -1 )
		{
			if ( line_max >= 5 ) { ty -= oc.unit_scrl; }
		}

	}

//n_game_hwndprintf_literal( " %d ", line_max );


	bool input_onoff = true;

	{

		s32 sx = N_BMP_SX( &p->bmp );
		s32 sy = N_BMP_SY( &p->bmp );
		s32  x = n_game_centering( game.sx, sx );
		s32  y = ty - sy - gap;

		if ( y > m )
		{
//n_bmp_box( &game.bmp, x,y,sx,sy, n_bmp_rgb( 0,200,255 ) );
			n_bmp_transcopy( &p->bmp, &game.bmp, 0,0,sx,sy, x,y );
		} else {
			input_onoff = false;
		}

	}

//n_bmp_save_literal( &p->bmp, "bmp.bmp" );


	s32 u = -( 4 * oc.unit_scal );

	s32 sx = 0;
	s32 sy = 0;
	s32 tx = 0;


	s32 datetime_f = 2;
	s32 datetime_t = 5;

	if ( n_string_is_empty( n_txt_get( &p->txtbox[ 2 ].txt, 0 ) ) )
	{
		datetime_f = datetime_t = -1;
	} else {
		if ( n_string_is_empty( n_txt_get( &p->txtbox[ 2 + 1 ].txt, 0 ) ) )
		{
			datetime_t = 3;
		} else {
			datetime_t = 5;
		}
	}


	s32 version_sx = 0;

	if (
		( datetime_t != -1 )
		&&
		( false == n_string_is_empty( n_txt_get( &p->txtbox[ datetime_t ].txt, 0 ) ) )
	)
	{

		int i = datetime_t;
		while( 1 )
		{

			s32 text_sx;
			n_win_stdsize_text( p->txtbox[ i ].hwnd, n_txt_get( &p->txtbox[ i ].txt, 0 ), &text_sx, NULL );
			text_sx = n_posix_minmax_double( (double) game.sx * 0.25, (double) game.sx * 0.5, text_sx );

			if ( version_sx < text_sx ) { version_sx = text_sx; }

			i++;
			if ( i >= N_OC_INFO_TXTBOX_MAX ) { break;}
		}

	}


	int i = 0;
	while( 1 )
	{

		s32 edit_x  = 0;
		s32 edit_y  = 0;
		s32 edit_sx = 0;
		s32 edit_sy = 0;

		sy = 0; n_win_stdsize_text( p->txtbox[ i ].hwnd, n_posix_literal( "a" ), NULL, &sy );

		if ( i == 0 )
		{

			sy = sy + ( bdr * 4 );

			sx = (double) game.sx * 0.5;
			tx = n_game_centering( game.sx, sx );

			edit_x  = tx;
			edit_y  = ty;
			edit_sx = sx;
			edit_sy = sy;

			edit_x  += ( bdr * 2 );
			edit_y  += ( bdr * 2 );
			edit_sx -= ( bdr * 4 );
			edit_sy -= ( bdr * 4 );

		} else {

			s32 text_sx;

			if ( i == 1 )
			{
				n_win_stdsize_text( p->txtbox[ i ].hwnd, n_txt_get( &p->txtbox[ i ].txt, 0 ), &text_sx, NULL );
				text_sx = n_posix_max_double( (double) game.sx * 0.25, text_sx );
			} else
			if ( ( datetime_f != -1 )&&( datetime_t != -1 )&&( i >= datetime_f )&&( i < datetime_t ) )
			{
				n_win_stdsize_text( p->txtbox[ i ].hwnd, n_posix_literal( "Create : 0000/00/00 00:00:00" ), &text_sx, NULL );
				text_sx = n_posix_max_double( (double) game.sx * 0.25, text_sx );
			} else {
				text_sx = version_sx;
			}

			sx = text_sx + ( gap * 4 );
			tx = n_game_centering( game.sx, sx );

			edit_x  = tx;
			edit_y  = ty;
			edit_sx = sx;
			edit_sy = sy;

		}

		p->edit_x [ i ] = edit_x;
		p->edit_y [ i ] = edit_y;
		p->edit_sx[ i ] = edit_sx;
		p->edit_sy[ i ] = edit_sy;

		if (
			( ( ( i <= 1 )&&( input_onoff ) )||( i > 1 ) )
			&&
			( i < line_max )
			&&
			( ( edit_sx > 0 )&&( edit_sy > 0 ) )
			&&
			( ( i == 0 )||( sx < p->edit_sx[ 0 ] ) )
			&&
			( ( ty > m )&&( ( ty + sy ) < ( game.sy - m ) ) )
		)
		{
//n_game_hwndprintf_literal( " %d ", line_max );
//if ( i == 1 ) { n_game_hwndprintf_literal( " %s : %d %d : %d : %d ", n_txt_get( &p->txtbox[ i ].txt, 0 ), ty, sy, game.sy - m, line_max ); }
//if ( i == 2 ) { n_game_hwndprintf_literal( " 1 : %d %d : %d ", sx, p->edit_sx[ 0 ], gap ); }

			u32 fg = p->fg;
			u32 bg = n_win_darkmode_systemcolor_rgb2pal( COLOR_WINDOW );

			if ( ( oc.dwm_onoff )&&( p->txtbox[ i ].style & N_WIN_TXTBOX_STYLE_TRANSBG ) ) { bg = 0; }

			if ( i == 0 )
			{
				if ( ( false == oc.dwm_onoff )&&( p->txtbox[ i ].txt.readonly ) ) { bg = n_gdi_systemcolor( COLOR_BTNFACE ); }
				//if ( p->txtbox[ i ].ime_onoff ) { fg = p->txtbox[ i ].color_back_selected; }

				fg = n_bmp_fade_engine( &p->fade, true );
				fg = n_bmp_alpha_visible_pixel( n_bmp_rgb2pal( fg ) );

				n_oc_frame( &game.bmp, tx,ty,sx,sy, bdr,u, fg,bg );
			} else
			if ( ( i == 1 )&&( oc.dwm_onoff )&&( false == n_string_is_empty( n_txt_get( &p->txtbox[ i ].txt, 0 ) ) ) )
			{
				s32 ftx = ( tx * 1 ) - ( bdr * 2 );
				s32 fty = ( ty * 1 ) - ( bdr * 2 );
				s32 fsx = ( sx * 1 ) + ( bdr * 4 );
				s32 fsy = ( sy * 1 ) + ( bdr * 4 );

				n_oc_frame( &game.bmp, ftx,fty,fsx,fsy, bdr,u, fg,bg );
			} else
			if ( ( i == 2 )&&( datetime_f != -1 ) )
			{
				int n = datetime_t - datetime_f;

				s32 ftx = ( tx * 1 ) - ( bdr * 2 );
				s32 fty = ( ty * 1 ) - ( bdr * 2 );
				s32 fsx = ( sx * 1 ) + ( bdr * 4 );
				s32 fsy = ( sy * n ) + ( bdr * 4 );

				n_oc_frame( &game.bmp, ftx,fty,fsx,fsy, bdr,u, fg,bg );
			} else
			if ( ( i == 5 )&&( p->drive_usage == -1 ) )
			{
				int n = 0;

				int j = i;
				while( 1 )
				{//break;
					if ( false == n_string_is_empty( n_txt_get( &p->txtbox[ j ].txt, 0 ) ) )
					{
						n++;
					}

					j++;
					if ( j >= N_OC_INFO_TXTBOX_MAX ) { break; }
				}

				s32 ftx = ( tx * 1 ) - ( bdr * 2 );
				s32 fty = ( ty * 1 ) - ( bdr * 2 );
				s32 fsx = ( sx * 1 ) + ( bdr * 4 );
				s32 fsy = ( sy * n ) + ( bdr * 4 );

				if ( n )
				{
					n_oc_frame( &game.bmp, ftx,fty,fsx,fsy, bdr,u, fg,bg );
				}
			}

			if (
				( i == 0 )
				||
				( false == n_string_is_empty( n_txt_get( &p->txtbox[ i ].txt, 0 ) ) )
			)
			{

				n_win_move_simple
				(
					p->txtbox[ i ].hwnd,
					edit_x,
					edit_y,
					edit_sx,
					edit_sy,
					false
				);

				if ( p->visible[ i ] == false )
				{
					n_bmp_free( &p->txtbox[ i ].prv_bmp );
				}

				p->visible[ i ] = true;

				ShowWindow( p->txtbox[ i ].hwnd, SW_SHOWNA );

			}

		} else {
//if ( i == 1 ) { n_game_hwndprintf_literal( " 2 " ); }

			p->visible[ i ] = false;

			ShowWindow( p->txtbox[ i ].hwnd, SW_HIDE );

		}


		ty += sy;

		if ( p->drive_usage == -1 )
		{
			if ( i == 0 ) { ty += gap * 4; } else
			if ( i == 1 ) { ty += gap * 4; } else
			if ( i == 4 ) { ty += gap * 4; }
		} else {
			if ( i == 0 ) { ty += gap * 4; } else
			if ( i == 1 ) { ty += gap * 4; }
		}


		i++;
		if ( i >= N_OC_INFO_TXTBOX_MAX ) { break; }
	}


	if ( p->drive_usage != -1 )
	{

		u32 fg = oc.scrollbar.color_thumb;
		u32 bg = oc.scrollbar.color_shaft;

		int percent = p->drive_usage;

		s32 bsx = (double) game.sx * 0.25;
		s32 bsy = oc.unit_scrl;
		s32 btx = n_game_centering( game.sx, bsx );
		s32 bty = ty - ( sy * 3 );

		if ( ( bty + bsy + ( gap * 1 ) ) > ( game.sy - m ) )
		{
			//
		} else {
			n_game_progressbar_horz( &game.bmp, btx,bty,bsx,bsy, fg,bg, percent, oc.stripe );

			if ( oc.style == N_ORANGECAT_STYLE_AERO )
			{
				u32 color_frame = n_bmp_blend_pixel( fg, N_ORANGECAT_COLOR_BLACK, 0.125 );
				n_oc_lineframe( &game.bmp, btx,bty,bsx,bsy, color_frame );
			}
		}

	}


	// [Needed] : Win95

	n_oc_info_input_refresh( p );


	return;
}

int
n_oc_info_drive
(
	const n_posix_char *name,
	      n_posix_char *ret_drivename,
	      n_posix_char *ret_size,
	      n_posix_char *ret_info_1,
	      n_posix_char *ret_info_2,
	      n_posix_char *ret_info_3
)
{

	n_posix_char vol_name[ N_OC_INFO_CCH_MAX ] = n_posix_literal( "N/A" );
	n_posix_char vol_fsys[ N_OC_INFO_CCH_MAX ] = n_posix_literal( "N/A" );
	u32          vol_info = 0;
	u32          vol_len  = 0;

	GetVolumeInformation
	(
		name,
		vol_name,
		N_OC_INFO_CCH_MAX,
		NULL,
		&vol_len,
		&vol_info,
		vol_fsys,
		N_OC_INFO_CCH_MAX
	);


	if ( ret_drivename != NULL )
	{
		n_string_copy( vol_name, ret_drivename );
	}


	n_posix_char type_str[ N_OC_INFO_CCH_MAX ]; n_string_zero( type_str, N_OC_INFO_CCH_MAX );
	UINT         type = n_sysinfo_drive_type( name );

	if ( type == DRIVE_UNKNOWN     ) { n_string_copy_literal( "DRIVE_UNKNOWN",     type_str ); } else
	if ( type == DRIVE_NO_ROOT_DIR ) { n_string_copy_literal( "DRIVE_NO_ROOT_DIR", type_str ); } else
	if ( type == DRIVE_REMOVABLE   ) { n_string_copy_literal( "DRIVE_REMOVABLE",   type_str ); } else
	if ( type == DRIVE_FIXED       ) { n_string_copy_literal( "DRIVE_FIXED",       type_str ); } else
	if ( type == DRIVE_REMOTE      ) { n_string_copy_literal( "DRIVE_REMOTE",      type_str ); } else
	if ( type == DRIVE_CDROM       ) { n_string_copy_literal( "DRIVE_CDROM",       type_str ); } else
	if ( type == DRIVE_RAMDISK     ) { n_string_copy_literal( "DRIVE_RAMDISK",     type_str ); }


	u64 disksize = 0;
	u64 usedsize = 0;
	u64 freesize = 0;

	if ( vol_info == 0 )
	{

		n_string_copy( N_STRING_SPACE, ret_size );

	} else {

		n_sysinfo_drive_size( name, &disksize, &freesize );
		usedsize = disksize - freesize;

		double gb_disk = (double) disksize / 1000 / 1000 / 1000;
		double gb_used = (double) usedsize / 1000 / 1000 / 1000;
		double gb_free = (double) freesize / 1000 / 1000 / 1000;

		n_posix_sprintf_literal( ret_size, "%.3f GB (%d GB used, %d GB free)", gb_disk, (int) gb_used, (int) gb_free );

	}

	n_posix_char info_str[ N_OC_INFO_CCH_MAX ]; n_string_zero( info_str, N_OC_INFO_CCH_MAX );
	n_posix_sprintf_literal( info_str, "0x%08lx", vol_info );


	int cch_1 = n_posix_strlen( type_str );
	int cch_2 = n_posix_strlen( vol_fsys );
	int cch_3 = n_posix_strlen( info_str );
	int maxim = n_posix_max( n_posix_max( cch_1, cch_2 ), cch_3 );

	if ( ( maxim - cch_1 ) != 0 )
	{
		n_posix_sprintf_literal( ret_info_1, "Drive Type  : %s%*s", type_str, maxim - cch_1, N_STRING_SPACE );
	} else {
		n_posix_sprintf_literal( ret_info_1, "Drive Type  : %s", type_str );
	}

	if ( ( maxim - cch_2 ) != 0 )
	{
		n_posix_sprintf_literal( ret_info_2, "File System : %s%*s", vol_fsys, maxim - cch_2, N_STRING_SPACE );
	} else {
		n_posix_sprintf_literal( ret_info_2, "File System : %s", vol_fsys );
	}

	if ( ( maxim - cch_3 ) != 0 )
	{
		n_posix_sprintf_literal( ret_info_3, "FS Flags    : %s%*s", info_str, maxim - cch_3, N_STRING_SPACE );
	} else {
		n_posix_sprintf_literal( ret_info_3, "FS Flags    : %s", info_str );
	}


	double usage = 0;

	if ( disksize != 0 )
	{
		usage = (double) ( disksize - freesize ) / disksize * 100;
	} else
	if ( vol_info == 0 )
	{
		usage = -1;
	}


	return usage;
}

#define n_oc_info_atime( name, ret ) n_oc_info_time( name, ret, N_TIME_ACCESS )
#define n_oc_info_ctime( name, ret ) n_oc_info_time( name, ret, N_TIME_CREATE )
#define n_oc_info_mtime( name, ret ) n_oc_info_time( name, ret, N_TIME_MODIFY )
#define n_oc_info_stime(       ret ) n_oc_info_time( NULL, ret, N_TIME_SYSTEM )

void
n_oc_info_time( const n_posix_char *name, n_posix_char *ret, int type )
{

	// [!] : this module based on n_time_string() @ neutral/time.c

	if ( ret == NULL ) { return; }


	n_time t;

	if ( type == N_TIME_ACCESS ) { t = n_time_atime( name ); } else
	if ( type == N_TIME_CREATE ) { t = n_time_ctime( name ); } else
	if ( type == N_TIME_MODIFY ) { t = n_time_mtime( name ); } else
	if ( type == N_TIME_SYSTEM ) { t = n_time_stime(      ); }


	SYSTEMTIME s;
	if ( type != N_TIME_SYSTEM ) { FileTimeToLocalFileTime( &t, &t ); }
	FileTimeToSystemTime( &t, &s );


	n_posix_char *frmt = n_posix_literal( "HH':'mm':'ss" );

	n_posix_char date[ 255 ], time[ 255 ];
	GetDateFormat( LOCALE_USER_DEFAULT, DATE_SHORTDATE, &s, NULL, date, 255 );
	GetTimeFormat( LOCALE_USER_DEFAULT,              0, &s, frmt, time, 255 );


	n_posix_sprintf_literal( ret, "%s %s", date, time );


	return;
}

void
n_oc_info_file_size( const n_posix_char *name, n_posix_char *ret_size )
{

	if ( n_posix_stat_is_dir( name ) )
	{

		n_string_copy_literal( "Folder", ret_size );

	} else {

		const int kb = 1000;
		const int mb = 1000 * 1000;
		const int gb = 1000 * 1000 * 1000;

		n_posix_structstat_size_t byte = n_posix_stat_size( name );
		if ( ( byte == 0 )&&( n_posix_stat_size_is_overflowed( name ) ) )
		{
			n_posix_sprintf_literal( ret_size, "Overflowed" );
			return;
		}

		double kilobyte = (double) byte / 1000;
		double megabyte = (double) byte / 1000 / 1000;
		double gigabyte = (double) byte / 1000 / 1000 / 1000;

		int cch = n_posix_sprintf_literal( ret_size, "%lu Byte", (u32) byte );

		if ( byte >= gb )
		{
			n_posix_sprintf_literal( &ret_size[ cch ], " (%.2f GB)", gigabyte );
		} else
		if ( byte >= mb )
		{
			n_posix_sprintf_literal( &ret_size[ cch ], " (%.2f MB)", megabyte );
		} else
		if ( byte >= kb )
		{
			n_posix_sprintf_literal( &ret_size[ cch ], " (%.2f KB)", kilobyte );
		}

	}


	return;
}

void
n_oc_info_file( n_oc_info *p, const n_posix_char *name )
{

	int i = 1;

	{

		n_posix_char ret_size[ N_OC_INFO_CCH_MAX ];

		n_oc_info_file_size( name, ret_size );

		n_win_txtbox_line_set( &p->txtbox[ i ], 0, ret_size ); i++;

	}


	if ( n_posix_stat_is_dir( name ) )
	{

		n_posix_char str_ctime[ N_OC_INFO_CCH_MAX ]; n_oc_info_ctime( name, str_ctime );
		n_posix_char str_c    [ N_OC_INFO_CCH_MAX ]; n_posix_sprintf_literal( str_c, "Create : %s", str_ctime );

		n_win_txtbox_line_set( &p->txtbox[ i ], 0, str_c ); i++;

	} else {

		n_posix_char str_ctime[ N_OC_INFO_CCH_MAX ]; n_oc_info_ctime( name, str_ctime );
		n_posix_char str_mtime[ N_OC_INFO_CCH_MAX ]; n_oc_info_mtime( name, str_mtime );
		n_posix_char str_atime[ N_OC_INFO_CCH_MAX ]; n_oc_info_atime( name, str_atime );

		n_posix_char str_c    [ N_OC_INFO_CCH_MAX ]; n_posix_sprintf_literal( str_c, "Create : %s", str_ctime );
		n_posix_char str_m    [ N_OC_INFO_CCH_MAX ]; n_posix_sprintf_literal( str_m, "Modify : %s", str_mtime );
		n_posix_char str_a    [ N_OC_INFO_CCH_MAX ]; n_posix_sprintf_literal( str_a, "Access : %s", str_atime );

		n_win_txtbox_line_set( &p->txtbox[ i ], 0, str_c ); i++;
		n_win_txtbox_line_set( &p->txtbox[ i ], 0, str_m ); i++;
		n_win_txtbox_line_set( &p->txtbox[ i ], 0, str_a ); i++;


		// [patch] : WinXP : n_string_truncate() is needed : I don't know why

		n_posix_char productname[ N_OC_INFO_CCH_MAX ]; n_string_truncate( productname );
		n_posix_char description[ N_OC_INFO_CCH_MAX ]; n_string_truncate( description );
		n_posix_char fileversion[ N_OC_INFO_CCH_MAX ]; n_string_truncate( fileversion );
		n_posix_char   copyright[ N_OC_INFO_CCH_MAX ]; n_string_truncate(   copyright );

		n_sysinfo_fileversion_literal( name, "ProductName",     productname, N_OC_INFO_CCH_MAX );
		n_sysinfo_fileversion_literal( name, "FileDescription", description, N_OC_INFO_CCH_MAX );
		n_sysinfo_fileversion_literal( name, "FileVersion",     fileversion, N_OC_INFO_CCH_MAX );
		n_sysinfo_fileversion_literal( name, "LegalCopyright",    copyright, N_OC_INFO_CCH_MAX );

		if ( false == n_string_is_empty( productname ) )
		{
			n_win_txtbox_line_set( &p->txtbox[ i ], 0, productname ); i++;
		}

		if (
			( false == n_string_is_empty( description ) )
			&&
			( false == n_string_is_same( productname, description ) )
		)
		{
			n_win_txtbox_line_set( &p->txtbox[ i ], 0, description ); i++;
		}

		if ( false == n_string_is_empty( fileversion ) )
		{
			n_win_txtbox_line_set( &p->txtbox[ i ], 0, fileversion ); i++;
		}

		if ( false == n_string_is_empty( copyright ) )
		{
			n_win_txtbox_line_set( &p->txtbox[ i ], 0, copyright ); i++;
		}

	}


	return;
}

void
n_oc_info_edit_off( n_oc_info *p )
{

	p->txtbox[ 0 ].txt.readonly = true;

	n_win_txtbox_grayed( &p->txtbox[ 0 ], true );


	return;
}

// internal
LRESULT CALLBACK
n_oc_info_on_keydown( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( wparam == VK_RETURN )
	{

		n_posix_sleep( N_ORANGECAT_INTERVAL_BASE );

		n_oc_event_viewchange();


		return true;

	}


	return false;
}

// internal
void
n_oc_info_input_focus( n_oc_info *p )
{

	int n;

	if ( item.view_type == N_ORANGECAT_VIEW_TYPE_PATH )
	{
		n = -1;
	} else {
		n_posix_char *str = n_string_path_name_new( n_txt_get( &info.txtbox[ 0 ].txt, 0 ) );
		n_string_path_ext_del( str );
//n_posix_debug_literal( " %s ", str );
		n = n_posix_strlen( str );
		n_string_path_free( str );
	}


	n_win_txtbox_unselect( &info.txtbox[ 0 ] );
	n_win_txtbox_select( &info.txtbox[ 0 ], 0,0, n,1 );


	return;
}

void
n_oc_info_init( n_oc_info *p, n_posix_char *name )
{

	{
		static bool is_first = true;

		if ( is_first )
		{
			is_first = false;
			n_oc_info_zero( p );
		}
	}


	n_oc_info_exit( p );


	// Phase 1 : input field

	{

		int i = 0;
		while( 1 )
		{

			int style = 0;

			style = style | N_WIN_TXTBOX_STYLE_ONELINE;
			style = style | N_WIN_TXTBOX_STYLE_NO_BRDR;
			style = style | N_WIN_TXTBOX_STYLE_NO_PDNG;
			//style = style | N_WIN_TXTBOX_STYLE__DI_HDC;
			//style = style | N_WIN_TXTBOX_STYLE_VISIBLE;
			if ( oc.dwm_onoff ) { style = style | N_WIN_TXTBOX_STYLE_TRANSBG; }

			int style_option = 0;

			style_option = style_option | N_WIN_TXTBOX_OPTION_ONELINE_HCENTER;
			style_option = style_option | N_WIN_TXTBOX_OPTION_ONELINE_LNCACHE;

			if ( i == 0 )
			{

				if ( oc.find_mode )
				{
					//
				} else {
					style_option = style_option | N_WIN_TXTBOX_OPTION_ONELINE_FILENAM;
				}

				n_win_txtbox_init( &p->txtbox[ i ], game.hwnd, style, style_option );

			} else
			if ( ( i == 1 )||( i >= 5 ) )
			{

				style_option = style_option | N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET;
				n_win_txtbox_init( &p->txtbox[ i ], game.hwnd, style, style_option );

			} else {

				style_option = style_option | N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET;
				n_win_txtbox_init( &p->txtbox[ i ], game.hwnd, style, style_option );


				HDC hdc = GetDC( p->txtbox[ i ].hwnd );

				LOGFONT lf_f; n_memory_zero( &lf_f, sizeof( LOGFONT ) ); 
				LOGFONT lf_t = n_win_font_hfont2logfont( n_win_stdfont_hfont() );

				// [x] : Win9x : "MS Gothic" is not available : a localized name is needed

				n_posix_char *fontname = n_gdi_font_find
				(
					n_posix_literal( "Consolas" ),
#ifdef UNICODE
					n_posix_literal( "\xff2d\xff33\x0020\x30b4\x30b7\x30c3\x30af" )           // Unicode LE
#else
					n_posix_literal( "\x82\x6c\x82\x72\x20\x83\x53\x83\x56\x83\x62\x83\x4e" ) // Shift-JIS
#endif
					n_posix_literal( "Courier New" ),
					n_posix_literal( "Courier" )
				);
				n_posix_sprintf_literal( lf_f.lfFaceName, "%s", fontname );
				bool ret = EnumFonts( hdc, NULL, n_gdi_font_enumfontsproc, (LPARAM) &lf_f );
//n_posix_debug_literal( "%d : %s", ret, lf_f.lfFaceName );
				ReleaseDC( p->txtbox[ i ].hwnd, hdc );

				if ( ret )
				{
					n_win_stdfont_init( &p->txtbox[ i ].hwnd, 1 );
				} else {
					n_posix_sprintf_literal( lf_t.lfFaceName, "%s", fontname );
					n_win_font_set( p->txtbox[ i ].hwnd, n_win_font_logfont2hfont( &lf_t ), true );
				}

			}


			if ( i != 0 ) { p->txtbox[ i ].txt.readonly = true; }


			i++;
			if ( i >= N_OC_INFO_TXTBOX_MAX ) { break; }
		}

	}


	if ( p->txtbox[ 0 ].hwnd != NULL )
	{

#ifdef _WIN64
		SetWindowSubclass( p->txtbox[ 0 ].hwnd, n_win_subclass_txtbox_on_keydown, 0, (DWORD_PTR) n_oc_info_on_keydown );
#else  // #ifdef _WIN64
		n_win_property_init_literal
		(
			p->txtbox[ 0 ].hwnd,
			"n_win_subclass_txtbox_on_keydown()",
			(int) n_win_gui_subclass_set( p->txtbox[ 0 ].hwnd, n_win_subclass_txtbox_on_keydown )
		);
		n_win_property_init_literal( p->txtbox[ 0 ].hwnd, "WM_KEYDOWN", (int) n_oc_info_on_keydown );
#endif // #ifdef _WIN64

	}


	// Phase 2

	n_posix_char size[ N_OC_INFO_CCH_MAX ]; n_string_zero( size, N_OC_INFO_CCH_MAX );
	n_posix_char  ver[ N_OC_INFO_CCH_MAX ]; n_string_zero(  ver, N_OC_INFO_CCH_MAX );


	p->drive_usage = -1;


	if ( oc.find_mode )
	{

		p->txtbox[ 0 ].placeholder = n_posix_literal( "Find" );

		n_win_txtbox_line_set( &p->txtbox[ 0 ], 0, name );

		p->icon = n_string_path_carboncopy( N_ORANGECAT_FIND );
		p->name = n_string_path_carboncopy(             name );

	} else {

		// [!] : N_ORANGECAT_FIND_MODE_NONE
//n_game_hwndprintf_literal( "%s", name );

		n_posix_char *str = NULL;

		if ( false == n_string_path_is_abspath( name ) )
		{

			if ( n_string_is_same( oc.cpnl, name ) )
			{

				str     = n_string_path_carboncopy( N_ORANGECAT_CONTROLPANEL );
				p->icon = n_string_path_carboncopy( oc.cpnl                  );

			} else
			if ( n_string_is_same( N_ORANGECAT_SETTINGS_EXE, name ) )
			{

				str     = n_string_path_carboncopy( N_ORANGECAT_SETTINGS     );
				p->icon = n_string_path_carboncopy( N_ORANGECAT_SETTINGS_EXE );

			} else
			if ( n_string_is_same( N_ORANGECAT_SHUTDOWN_EXE, name ) )
			{

				str     = n_string_path_carboncopy( N_ORANGECAT_SHUTDOWN     );
				p->icon = n_string_path_carboncopy( N_ORANGECAT_SHUTDOWN_EXE );

			} else {

				p->is_computer_on_breadcrumb = true;


				// [!] : winbase.h : MAX_COMPUTERNAME_LENGTH 15

				DWORD dw  = MAX_COMPUTERNAME_LENGTH + 1;
				      str = n_string_path_new( dw );

				GetComputerName( str, &dw );


				p->icon = n_string_path_carboncopy( N_STRING_EMPTY );

			}

			n_win_txtbox_line_set( &p->txtbox[ 0 ], 0, str );

			p->name = n_string_path_carboncopy( str );

		} else
		if ( n_string_path_is_drivename( name ) )
		{

			p->icon = n_string_path_carboncopy( name );

			n_posix_char info_1[ N_OC_INFO_CCH_MAX ]; n_string_zero( info_1, N_OC_INFO_CCH_MAX );
			n_posix_char info_2[ N_OC_INFO_CCH_MAX ]; n_string_zero( info_2, N_OC_INFO_CCH_MAX );
			n_posix_char info_3[ N_OC_INFO_CCH_MAX ]; n_string_zero( info_3, N_OC_INFO_CCH_MAX );

			str            = n_string_path_new( N_OC_INFO_CCH_MAX );
			p->drive_usage = n_oc_info_drive( name, str, size, info_1, info_2, info_3 );

			n_win_txtbox_line_set( &p->txtbox[ 0 ], 0, str    );
			n_win_txtbox_line_set( &p->txtbox[ 1 ], 0, size   );
			n_win_txtbox_line_set( &p->txtbox[ 2 ], 0, info_1 );
			n_win_txtbox_line_set( &p->txtbox[ 3 ], 0, info_2 );
			n_win_txtbox_line_set( &p->txtbox[ 4 ], 0, info_3 );

			p->name = n_string_path_carboncopy( str );

			p->drive_label_is_empty = n_string_is_empty( str );

		} else {

			p->icon = n_string_path_carboncopy( name );

			n_oc_info_file( p, name );


			if ( item.view_type == N_ORANGECAT_VIEW_TYPE_PATH )
			{
				n_win_txtbox_line_set( &p->txtbox[ 0 ], 0, name );
			} else {
				str = n_string_path_name_new( name );

				n_win_txtbox_line_set( &p->txtbox[ 0 ], 0, str );
			}


			// [!] : remember as an absolute path

			p->name = n_string_path_carboncopy( name );

		}

		n_string_path_free( str );


		if ( p->is_computer_on_breadcrumb )
		{

			// [!] : currently read-only

			n_oc_info_edit_off( p );

		} else
		if ( item.view_type == N_ORANGECAT_VIEW_TYPE_PATH )
		{

			n_oc_info_edit_off( p );

		} else
		if ( n_string_is_same( oc.cpnl, name ) )
		{

			n_oc_info_edit_off( p );

		} else
		if ( n_string_is_same( N_ORANGECAT_SETTINGS_EXE, name ) )
		{

			n_oc_info_edit_off( p );

		} else
		if ( n_string_is_same( N_ORANGECAT_SHUTDOWN_EXE, name ) )
		{

			n_oc_info_edit_off( p );

		} else
		if ( item.find_onoff )
		{

			// [x] : currently not supported

			n_oc_info_edit_off( p );

		} else
		if ( n_string_path_is_drivename( name ) )
		{

			UINT type = n_sysinfo_drive_type( name );

			if (
				( type == DRIVE_UNKNOWN )
				||
				( type == DRIVE_CDROM   )
			)
			{
				n_oc_info_edit_off( p );
			}

		//} else
		//if ( 2 <= n_oc_item_multifocus_count( &item ) )
		//{

			//n_oc_info_edit_off( p );

		} else {

			// [!] : for breadcrumb address band

			n_posix_char *foldername = n_string_path_upperfolder_new( name ); n_string_path_drivename_slash_add( foldername );
//n_game_hwndprintf_literal( "%s : %s : %s", name, foldername, oc.main );

			if ( n_posix_strlen( foldername ) < n_posix_strlen( oc.main ) )
			{
				n_oc_info_edit_off( p );
			}

			n_string_path_free( foldername );

		}


		n_oc_info_input_focus( p );

	}


	{

		n_gdi_zero( &p->gdi );

		n_posix_char *path_default = n_string_path_carboncopy( p->icon );

		p->gdi.icon        = n_oc_patch_iconpath_new  ( path_default, p->is_computer_on_breadcrumb );
		p->gdi.icon_index  = n_oc_patch_iconpath_index( path_default, p->is_computer_on_breadcrumb );

		if (
			( oc.find_mode == N_ORANGECAT_FIND_MODE_NONE )
			&&
			( p->is_computer_on_breadcrumb == false )
		)
		{

			p->gdi.icon_style |= oc.icon_resource;
			if ( oc.view_is_computer )
			{
				if ( n_string_is_same( N_ORANGECAT_CONTROLPANEL, p->name ) )
				{
					p->gdi.icon_style &= ~N_GDI_ICON_RC_RESOLVE;
				} else
				if ( n_string_is_same( N_ORANGECAT_SHUTDOWN_EXE, p->icon ) )
				{
//n_game_hwndprintf_literal( "%s : %d", p->gdi.icon, p->gdi.icon_index );
					p->gdi.icon_style &= ~N_GDI_ICON_RC_RESOLVE;
				}
			} else {
				if ( n_oc_patch_is_recyclebin( p->name ) )
				{
					p->gdi.icon_style &= ~N_GDI_ICON_RC_RESOLVE;
				}
			}

		}

		if ( oc.view_gallery_size != 32 )
		{
			p->gdi.icon_style  |=  oc.view_gallery_style;
		} else {
			p->gdi.icon_style  &= ~oc.view_gallery_style;
		}

		p->gdi.icon_rsrc = -1;

		p->gdi.base_color_bg = n_bmp_white_invisible;
		p->gdi.base_color_fg = n_bmp_white_invisible;

		s32 icon_size = GetSystemMetrics( SM_CXICON ); icon_size += icon_size / 4;

		p->gdi.icon_sx = icon_size;
		p->gdi.icon_sy = icon_size;

		n_gdi_bmp( &p->gdi, &p->bmp );
//n_bmp_save_literal( &p->bmp, "bmp.bmp" );


		n_string_path_free( p->icon );
		p->icon = p->gdi.icon;


		n_string_path_free( path_default );

	}


	SetFocus( p->txtbox[ 0 ].hwnd );


	n_bmp_fade_init( &p->fade, n_oc_info_fade_color( p ) );


	// Phase 3 : pre-flush a canvas for performance

	n_oc_info_flush( &p->fg, &p->bg, &game.color );


	return;
}

