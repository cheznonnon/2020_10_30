// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {

	u32 last_count;

	u32 interval;
	s32 oy, cores;

} n_oc_item_preload_thread_struct;

void
n_oc_item_preload_thread_main( n_oc_item_preload_thread_struct *p )
{
//n_posix_debug_literal( " %d ", p->oy );
//if ( p->oy != 0 ) { return; } else { p->cores = 1; }


	u32 timer = n_posix_tickcount();

//	HANDLE hmutex = NULL;

	int i = p->oy;
	while( 1 )
	{//break;

		if ( i >= item.count ) { break; }


		// [x] : CriticalSection : not working

//CRITICAL_SECTION cs; InitializeCriticalSection( &cs );

/*
		// [Needed] : Mutex : needed because somewhere is broken

		bool timeout = false;

		while( 1 )
		{
			if ( n_game_timer( &timer, p->interval ) ) { timeout = true; break; }

			// [x] : don't use WaitForSingleObject() : memory leak

			hmutex = n_win_mutex_init_literal( hmutex, "n_oc_item_preload_thread_main()" );
			if ( hmutex != NULL ) { break; } else { n_posix_sleep( 5 ); }
		}

		if ( timeout ) { break; }
*/

		n_oc_item_preload_single( &item, i, false );
		i += p->cores;


//		hmutex = n_win_mutex_exit( hmutex );


//DeleteCriticalSection( &cs );

		if ( n_game_timer( &timer, p->interval ) ) { break; }

	}


	p->last_count = i;


	return;
}

n_thread_return
n_oc_item_preload_thread( n_thread_argument p )
{

	n_oc_item_preload_thread_main( p );

	return 0;
}

void
n_oc_item_preload_thread_go( u32 interval )
{

	if ( n_oc_item_error( &item ) ) { return; }

	if ( item.count <= 0 ) { return; }


	// [!] : test phase : off by default : see oc_ini.c

	//oc.global_thread_onoff = false;

	if (
		( oc.global_thread_onoff )
		&&
		( n_thread_onoff() )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_oc_item_preload_thread_go() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG

		bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = true;

		bool p_trans = n_bmp_transparent_onoff_default;
		n_bmp_transparent_onoff_default = true;


		s32 cores = n_thread_core_count;

		n_thread                        *h = n_memory_new( cores * sizeof( n_thread                        ) );
		n_oc_item_preload_thread_struct *p = n_memory_new( cores * sizeof( n_oc_item_preload_thread_struct ) );


		size_t i = 0;
		while( 1 )
		{

			n_oc_item_preload_thread_struct tmp = { 0, interval, i,cores };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_oc_item_preload_thread_struct ) );

			h[ i ] = n_thread_init( n_oc_item_preload_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		u32 max_count = 0;

		i = 0;
		while( 1 )
		{

			if ( max_count < p[ i ].last_count )
			{
				max_count = p[ i ].last_count;
			}

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;


		// [!] : load not loaded items

		i = 0;
		while( 1 )
		{
			if ( i >= max_count ) { break; }

			n_oc_item_preload_single( &item, i, false );

			i++;
		}


		n_bmp_transparent_onoff_default = p_trans;


		n_oc_item_progressbar_main( &item.progress_sync, item.load_count, item.count );

	} else {

		n_oc_item_preload_thread_struct tmp = { 0, interval, 0,1 };

		n_oc_item_preload_thread_main( &tmp );

	}


	return;
}

