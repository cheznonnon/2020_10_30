// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




static bool n_oc_item_autoscroll_debug_onoff = false;




// internal
void
n_oc_item_autoscroll_calculate( n_oc_item *p, int index, s32 *ret_unit_x, s32 *ret_unit_y )
{

	// [!] : unit based

	s32 unit_x = ( index % (s32) p->scroll_item_per_line );
	s32 unit_y = ( index / (s32) p->scroll_item_per_line );

	if ( ret_unit_x != NULL ) { (*ret_unit_x) = unit_x; }
	if ( ret_unit_y != NULL ) { (*ret_unit_y) = unit_y; }


if ( n_oc_item_autoscroll_debug_onoff )
{
	n_game_hwndprintf_literal( " %d %d ", unit_x, unit_y );
}

	return;
}

bool
n_oc_item_autoscroll_is_inner_by_pixelpos( n_oc_item *p, s32 pixel_x, s32 pixel_y )
{

	if ( n_oc_item_error( p ) ) { return false; }

	if ( p->count == 0 ) { return false; }


	bool ret = false;


	s32 cell = 0;
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		cell = p->cell_sx - ( p->ox * 2 );
	} else {
		cell = p->cell_sy - ( p->oy * 2 );
	}


	s32 offset_f, offset_t;
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		offset_f = pixel_x;
		offset_t = pixel_x + cell;
	} else {
		offset_f = pixel_y - oc.unit_path;
		offset_t = pixel_y + cell;
	}

	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		//
	} else {
		//offset_f -= oc.unit_path;
		offset_t -= oc.unit_path + oc.unit_mrgn;
	}


	s32 size;
	if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
	{
		size = p->sx;
	} else {
		size = p->sy;
	}


	if ( ( offset_f >= 0 )&&( offset_t < size ) ) { ret = true; }

	if ( oc.scrollbar.unit_pos == ( oc.scrollbar.unit_max - oc.scrollbar.unit_page ) )
	{
		if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
		{
			size += p->cell_sx;
		} else {
			size += p->cell_sy;
		}
		if ( ( offset_f >= 0 )&&( offset_t < size ) ) { ret = true; }
	}


if ( n_oc_item_autoscroll_debug_onoff )
{
	n_game_hwndprintf_literal( " is_inner() : From %d To %d : Client 0-%d : Ret %d ", offset_f,offset_t, size, ret );
}

	return ret;
}

bool
n_oc_item_autoscroll_is_inner( n_oc_item *p, int index )
{

	if ( ( index < 0 )||( index >= p->count ) ) { return false; }

	s32 x,y; n_oc_item_position_calculate( p, index, &x, &y, true );

	return n_oc_item_autoscroll_is_inner_by_pixelpos( p, x,y );
}

bool
n_oc_item_autoscroll_is_edge( n_oc_item *p, int index, bool *ret_before, bool *ret_after )
{

	// [!] : this module works for half-hidden items


	if ( n_oc_item_error( p ) ) { return false; }

	if ( p->count == 0 ) { return false; }

	if ( ( index < 0 )||( index >= p->count ) ) { return false; }


	bool before = false;
	bool after  = false;

	if ( false == n_oc_item_autoscroll_is_inner( p, index ) )
	{

		s32 offset = (s32) p->scroll_item_per_line;

		before = n_oc_item_autoscroll_is_inner( p, index + offset );
		after  = n_oc_item_autoscroll_is_inner( p, index - offset );

	}


	if ( ret_before != NULL ) { (*ret_before) = before; }
	if ( ret_after  != NULL ) { (*ret_after ) = after ; }


if ( n_oc_item_autoscroll_debug_onoff )
{
	n_game_hwndprintf_literal( " is_edge() : %d %d : Index %d ", before, after, index );
}

	return before | after;
}

void
n_oc_item_autoscroll( n_oc_item *p, int index, int option )
{

	if ( n_oc_item_error( p ) ) { return; }

	if ( p->count == 0 ) { return; }

	if ( ( index < 0 )||( index >= p->count ) ) { return; }


//n_oc_item_autoscroll_calculate( p, index, NULL, NULL ); return;
//n_oc_item_autoscroll_is_inner ( p, index             ); return;
//n_oc_item_autoscroll_is_edge  ( p, index, NULL, NULL ); return;


	if ( option == N_OC_ITEM_AUTOSCROLL_SMART )
	{

		s32 fx,fy; n_oc_item_position_calculate( p, index, &fx, &fy, true );

		s32 tx = fx + p->cell_sx;
		s32 ty = fy + p->cell_sy;
//n_game_hwndprintf_literal( " %d %d : %d %d : %g %g ", fx,fy, tx,ty, p->sx,p->sy );

		if (
			( fx < ( -p->cell_sx ) )
			||
			( fy < ( -p->cell_sy ) )
			||
			( tx >= ( p->sx + p->cell_sx ) )
			||
			( ty >= ( p->sy + p->cell_sy ) )
		)
		{
			n_oc_item_autoscroll( p, index, N_OC_ITEM_AUTOSCROLL_CENTERING );
		}

	} else
	if ( option == N_OC_ITEM_AUTOSCROLL_CENTERING )
	{

		s32 x,y; n_oc_item_autoscroll_calculate( p, index, &x, &y );

		s32 offset;
		if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
		{
			offset = x * p->cell_sx;
		} else {
			offset = y * p->cell_sy;
		}

		s32 pos = offset - ( oc.scrollbar.unit_page / 2 );

		oc.scrollbar.unit_pos = 0;
		n_win_scrollbar_scroll_unit( &oc.scrollbar, pos, N_WIN_SCROLLBAR_SCROLL_AUTO );

	} else {

		bool before, after;
		n_oc_item_autoscroll_is_edge( p, index, &before, &after );
		if ( before )
		{

			s32 x,y; n_oc_item_position_calculate( p, index, &x, &y, true );

			s32 pos;
			if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
			{
				pos = x - p->ox;
				if ( oc.cursor_x < ( oc.unit_path + p->ox ) ) { pos += p->ox; }
			} else {
				pos = y - p->oy - oc.unit_path;
				if ( oc.cursor_y < ( oc.unit_path + p->oy ) ) { pos += p->oy; }
			}

			n_win_scrollbar_scroll_unit( &oc.scrollbar, pos, N_WIN_SCROLLBAR_SCROLL_AUTO );

		} else
		if ( after )
		{
//n_game_debug_count();
			s32 x,y; n_oc_item_position_calculate( p, index, &x, &y, true );

			s32 pos;
			if ( p->view_type == N_ORANGECAT_VIEW_TYPE_LOGO )
			{
				pos = ( x + p->cell_sx - p->sx                ) - p->ox;
				if ( ( oc.cursor_x                ) > ( p->sx - p->ox ) ) { pos -= p->ox; }
			} else {
				pos = ( y + p->cell_sy - p->sy - oc.unit_path ) - p->oy;
				if ( ( oc.cursor_y - oc.unit_path ) > ( p->sy - p->oy ) ) { pos -= p->oy; }
//n_game_hwndprintf_literal( "%d %d", oc.cursor_y - oc.unit_path, (int) ( p->sy - p->oy ) );
			}

			n_win_scrollbar_scroll_unit( &oc.scrollbar, pos, N_WIN_SCROLLBAR_SCROLL_AUTO );

		}

	}


	return;
}


