// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




static n_posix_char n_oc_font_name[ LF_FACESIZE ];
static s32          n_oc_font_size;
static int          n_oc_font_smooth;
static bool         n_oc_font_is_minus;




void
n_oc_font_smooth_set( bool onoff_auto, bool onoff_override )
{

	bool onoff = false;


	if ( n_sysinfo_version_vista_or_later() )
	{

		const UINT n_SPI_GETCLEARTYPE = 4168;

		SystemParametersInfo( n_SPI_GETCLEARTYPE, 0, &onoff, 0 );

	} else
	if ( n_sysinfo_version_xp_or_later() )
	{

		const UINT n_SPI_GETFONTSMOOTHINGTYPE = 8202;

		//const UINT n_FE_FONTSMOOTHINGSTANDARD  = 0x0001;
		//const UINT n_FE_FONTSMOOTHINGCLEARTYPE = 0x0002;

		SystemParametersInfo( n_SPI_GETFONTSMOOTHINGTYPE, 0, &onoff, 0 );

	} else
	//if ( n_sysinfo_version_nt() )
	{

		SystemParametersInfo( SPI_GETFONTSMOOTHING, 0, &onoff, 0 );

	}


	if ( onoff_auto == false )
	{
		onoff = onoff_override;
	}


	n_oc_font_smooth = N_GDI_TEXT_DEFAULT | N_GDI_TEXT_ELLIPSIS;

	if ( oc.dwm_onoff )
	{
		n_oc_font_smooth |= N_GDI_TEXT_BOLD;
		n_oc_font_smooth |= N_GDI_TEXT_SMOOTH;
		n_oc_font_smooth |= N_GDI_TEXT_CONTOUR;
	} else
	if ( onoff )
	{
		n_oc_font_smooth |= N_GDI_TEXT_BOLD;
		if ( n_win_darkmode_onoff )
		{
			n_oc_font_smooth |= N_GDI_TEXT_SMOOTH;
		} else {
			n_oc_font_smooth |= N_GDI_TEXT_CLEAR;
		}
	}



	return;
}

void
n_oc_font_init( bool onoff_auto, bool onoff_override )
{

	int              cb = sizeof( NONCLIENTMETRICS );
	NONCLIENTMETRICS ncm; ZeroMemory( &ncm, cb );

	ncm.cbSize = cb;
	SystemParametersInfo( SPI_GETNONCLIENTMETRICS, cb, &ncm, 0 );

	n_string_copy( ncm.lfMessageFont.lfFaceName, n_oc_font_name );


	// [!] : ncm.lfMessageFont.lfHeight : minus value
	//
	//	Vista or later : minus value is more important than older versions

	n_oc_font_size = ncm.lfMessageFont.lfHeight;
	//n_oc_font_size = ncm.lfCaptionFont.lfHeight;
	//n_oc_font_size = ncm.lfMenuFont.lfHeight;

	n_oc_font_is_minus = ( n_oc_font_size < 0 );	


/*
	// [!] : debug for Style Changer

	static int i = 0;
	if ( i % 2 ) { n_oc_font_size = 15; } else { n_oc_font_size = 23; }
	i++;
*/


	// [!] : debug for wheeling

	//if ( n_oc_font_size < 0 ) { n_oc_font_size *= -1; n_oc_font_is_minus = false; }


	n_oc_font_smooth_set( onoff_auto, onoff_override );


	return;
}

