
void
n_posix_pipeexec( const n_posix_char *command, n_posix_char *str_ret, size_t str_cch )
{

#ifdef N_POSIX_PLATFORM_WINDOWS

	// [x] : some DOS commands will return error 0x6d (109)
	//
	//	#define ERROR_BROKEN_PIPE 109L

	// [!] : Win95 : SetHandleInformation() always returns FALSE
	// [!] : WinNT : DuplicateHandle() is not needed


	// Phase 1 : initialization

	SECURITY_ATTRIBUTES sa;

	sa.nLength              = sizeof( SECURITY_ATTRIBUTES );
	sa.lpSecurityDescriptor = NULL; 
	sa.bInheritHandle       = TRUE; 

	HANDLE h_r = NULL;
	HANDLE h_w = NULL;

	if ( CreatePipe( &h_r, &h_w, &sa, 0 ) )
	{

		//HANDLE hproc  = GetCurrentProcess();
		//DuplicateHandle( hproc, h_w, hproc, NULL, 0, FALSE, DUPLICATE_SAME_ACCESS );

		//SetHandleInformation( h_w, HANDLE_FLAG_INHERIT, 0 );

	} else {
n_posix_debug_literal( "CreatePipe()" );

		return;
	}


	// Phase 2 : execution

	STARTUPINFO         si; GetStartupInfo( &si );
	PROCESS_INFORMATION pi; ZeroMemory( &pi, sizeof( PROCESS_INFORMATION ) );

	si.dwFlags     = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
	si.wShowWindow = SW_HIDE;
	si.hStdInput   = GetStdHandle( STD_INPUT_HANDLE  );
	si.hStdOutput  = h_w;//GetStdHandle( STD_OUTPUT_HANDLE );
	si.hStdError   = h_w;//GetStdHandle( STD_ERROR_HANDLE  );


	n_posix_char *s = n_string_carboncopy( command );

	BOOL ret = CreateProcess
	(
		NULL,
		s,
		NULL, NULL,
		TRUE,
		NORMAL_PRIORITY_CLASS,
		NULL,
		NULL,
		&si, &pi
	);

	n_memory_free( s );


	if ( ret )
	{

		WaitForSingleObject( pi.hProcess, INFINITE );

		DWORD d = 0;
		BOOL  b = ReadFile( h_r, str_ret, str_cch, &d, NULL );
		DWORD e = GetLastError();

n_posix_debug_literal
(
	"--------------------\n"
	"BOOL   %d (TRUE is succeeded)\n"
	"DWORD  %d \n"
	"Error  %d \n"
	"--------------------\n"
	"%s\n"
	"--------------------\n",
	b, d, e,
	str_ret
);

	} else {
n_posix_debug_literal( "CreateProcess()" );

	}

	CloseHandle( h_w );
	CloseHandle( h_r );


	CloseHandle( pi.hThread  );
	CloseHandle( pi.hProcess );


#else // #ifdef N_POSIX_PLATFORM_WINDOWS


#ifdef UNICODE
	FILE *p = _wpopen( command, L"r" );
#else  // #ifdef UNICODE
	FILE *p =   popen( command,  "r" );
#endif // #ifdef UNICODE

	if ( p != NULL ) { n_posix_fread( str_ret, str_cch, 1, p ); }

	pclose( p );


#endif // #ifdef N_POSIX_PLATFORM_WINDOWS


	return;
}
