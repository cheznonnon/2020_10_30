// Nonnon COM : IOleInPlaceSite
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed




#ifndef _H_NONNON_WIN32_COM_IOLEINPLACESITE
#define _H_NONNON_WIN32_COM_IOLEINPLACESITE




static HWND n_IOleInPlaceSite_hwnd = NULL;




//#include "./IOleInPlaceFrame.c"




HRESULT __stdcall
n_IOleInPlaceSite_IUnknown_QueryInterface( IOleInPlaceSite *_this, REFIID iid, void **ppvObject )
{
//n_com_debug_a( "n_IOleInPlaceSite_IUnknown_QueryInterface" );

	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID o = n_com_guid( n_guid_IID_IOleInPlaceSite );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &o ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}




HRESULT __stdcall
n_IOleInPlaceSite_IOleWindow_GetWindow( IOleInPlaceSite *_this, HWND *phwnd )
{

	if ( phwnd == NULL ) { return E_INVALIDARG; }


	*phwnd = n_IOleInPlaceSite_hwnd;


	return S_OK;
}

HRESULT __stdcall
n_IOleInPlaceSite_IOleWindow_ContextSensitiveHelp( IOleInPlaceSite *_this, BOOL fEnterMode )
{
	return E_NOTIMPL;
}




HRESULT __stdcall
n_IOleInPlaceSite_CanInPlaceActivate( IOleInPlaceSite *_this )
{
	return S_OK;
}

HRESULT __stdcall
n_IOleInPlaceSite_OnInPlaceActivate( IOleInPlaceSite *_this )
{
	return S_OK;
}

HRESULT __stdcall
n_IOleInPlaceSite_OnUIActivate( IOleInPlaceSite *_this )
{
	return S_OK;
}

HRESULT __stdcall
n_IOleInPlaceSite_GetWindowContext
(
	IOleInPlaceSite        *_this,
	IOleInPlaceFrame      **ppFrame,
	IOleInPlaceUIWindow   **ppDoc,
	LPRECT                  lprcPosRect,
	LPRECT                  lprcClipRect,
	LPOLEINPLACEFRAMEINFO   lpFrameInfo
)
{
N_COM_DEBUG_LISTBOX_SET_A( " IOleInPlaceSite_GetWindowContext " );


	if ( ppFrame != NULL ) { (*ppFrame) = NULL; }
	if ( ppDoc   != NULL ) { (*ppDoc  ) = NULL; }


#ifdef _H_NONNON_WIN32_COM_IOLEINPLACEFRAME

	if ( ppFrame != NULL ) { (*ppFrame) = (void*) &n_IOleInPlaceFrame_instance; }
	if ( ppDoc   != NULL ) { (*ppDoc  ) = (void*) &n_IOleInPlaceFrame_instance; }

#endif // #ifdef _H_NONNON_WIN32_COM_IOLEINPLACEFRAME


	HWND hwnd = n_IOleInPlaceSite_hwnd;

	GetClientRect( hwnd, lprcPosRect  );
	GetClientRect( hwnd, lprcClipRect );

	lpFrameInfo->fMDIApp       = FALSE;
	lpFrameInfo->hwndFrame     = hwnd;
	lpFrameInfo->haccel        = NULL;
	lpFrameInfo->cAccelEntries = 0;


	return S_OK;
}




HRESULT __stdcall
n_IOleInPlaceSite_Scroll( IOleInPlaceSite *_this, SIZE scrollExtant )
{
N_COM_DEBUG_LISTBOX_SET_A( " IOleInPlaceSite_Scroll " );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IOleInPlaceSite_OnUIDeactivate( IOleInPlaceSite *_this, BOOL fUndoable )
{
N_COM_DEBUG_LISTBOX_SET_A( " IOleInPlaceSite_OnUIDeactivate " );

	// [!] : this comes when IOleObject_Close()

	return S_OK;
}

HRESULT __stdcall
n_IOleInPlaceSite_OnInPlaceDeactivate( IOleInPlaceSite *_this )
{
N_COM_DEBUG_LISTBOX_SET_A( " IOleInPlaceSite_OnInPlaceDeactivate " );

	// [!] : this comes when IOleObject_Close()

	return S_OK;
}

HRESULT __stdcall
n_IOleInPlaceSite_DiscardUndoState( IOleInPlaceSite *_this )
{
N_COM_DEBUG_LISTBOX_SET_A( " IOleInPlaceSite_DiscardUndoState " );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IOleInPlaceSite_DeactivateAndUndo( IOleInPlaceSite *_this )
{
N_COM_DEBUG_LISTBOX_SET_A( " IOleInPlaceSite_DeactivateAndUndo " );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IOleInPlaceSite_OnPosRectChange( IOleInPlaceSite *_this, LPCRECT lprcPosRect )
{
N_COM_DEBUG_LISTBOX_SET_A( " IOleInPlaceSite_OnPosRectChange " );

	// [!] : this comes when some navigation is done

	return S_OK;
}




const void *n_IOleInPlaceSite_Vtbl[] = {

	n_IOleInPlaceSite_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,

	n_IOleInPlaceSite_IOleWindow_GetWindow,
	n_IOleInPlaceSite_IOleWindow_ContextSensitiveHelp,

	n_IOleInPlaceSite_CanInPlaceActivate,
	n_IOleInPlaceSite_OnInPlaceActivate,
	n_IOleInPlaceSite_OnUIActivate,
	n_IOleInPlaceSite_GetWindowContext,
	n_IOleInPlaceSite_Scroll,
	n_IOleInPlaceSite_OnUIDeactivate,
	n_IOleInPlaceSite_OnInPlaceDeactivate,
	n_IOleInPlaceSite_DiscardUndoState,
	n_IOleInPlaceSite_DeactivateAndUndo,
	n_IOleInPlaceSite_OnPosRectChange

};


IOleInPlaceSite n_IOleInPlaceSite_instance = { (void*) n_IOleInPlaceSite_Vtbl };




#endif // _H_NONNON_WIN32_COM_IOLEINPLACESITE

