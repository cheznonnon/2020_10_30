// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed


// Link : -lole32




#ifndef _H_NONNON_WIN32_OLE_IDATAOBJECT
#define _H_NONNON_WIN32_OLE_IDATAOBJECT




#include "../../neutral/posix.c"


//#include "./_debug.c"


#include <oleidl.h>
#include <shlobj.h>




const GUID n_IDataObject_guid_IID_IUnknown    = { 0x00000000,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };
const GUID n_IDataObject_guid_IID_IDataObject = { 0x0000010e,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };




#define n_IDataObject_support 1




static bool      n_IDataObject_is_dnd  = false;
static size_t    n_IDataObject_counter = 0;

static FORMATETC n_IDataObject_FORMATETC[ n_IDataObject_support ];
static STGMEDIUM n_IDataObject_STGMEDIUM[ n_IDataObject_support ];




//#include "./IEnumFORMATETC.c"




void
n_IDataObject_cursor_set( DROPFILES *df )
{

	if ( df == NULL ) { return; }


	GetCursorPos( &df->pt );

	ScreenToClient( WindowFromPoint( df->pt ), &df->pt );

	df->fNC = false;


	return;
}




HRESULT __stdcall
n_IDataObject_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{

	(*ppvObject) = NULL;

	if (
		( n_memory_is_same( iid, &n_IDataObject_guid_IID_IUnknown,    sizeof( GUID ) ) )
		||
		( n_memory_is_same( iid, &n_IDataObject_guid_IID_IDataObject, sizeof( GUID ) ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}

ULONG __stdcall
n_IDataObject_AddRef( void *_this )
{
	return S_OK;
}

ULONG __stdcall
n_IDataObject_Release( void *_this )
{
	return S_OK;
}

HRESULT __stdcall
n_IDataObject_GetData( void *_this, FORMATETC *pFormatetc, STGMEDIUM *pmedium )
{

	// [Needed] : IDropSource_QueryContinueDrag() returns DRAGDROP_S_DROP

	// [!] : DoDragDrop() : this will come when self-dnd'ed
	//
	//	a : MyEXE => Edit Control
	//	b : MyEXE => Another MyEXE
	//	c : MyEXE => CF_HDROP implemented applications
	//
	//	Explorer doesn't accept CF_HDROP
	//	search MSDN "Handling Shell Data Transfer Scenarios"


	if ( pFormatetc->lindex != -1 )
	{
		return DV_E_LINDEX;
	} else
	if ( pFormatetc->tymed != TYMED_HGLOBAL )
	{
		return DV_E_TYMED;
	} else
	if ( pFormatetc->dwAspect != DVASPECT_CONTENT )
	{
		return DV_E_DVASPECT;
	}


	size_t i = 0;
	while( 1 )
	{

		if ( pFormatetc->cfFormat == n_IDataObject_FORMATETC[ i ].cfFormat )
		{

			if ( pFormatetc->cfFormat == CF_HDROP )
			{
/*
				STGMEDIUM *sm = &n_IDataObject_STGMEDIUM[ i ];
				DROPFILES *df = GlobalLock( sm->hGlobal );

				n_IDataObject_cursor_set( df );

				GlobalUnlock( sm->hGlobal );
*/

				n_memory_copy( &n_IDataObject_STGMEDIUM[ i ], pmedium, sizeof( STGMEDIUM ) );
				return S_OK;

			} // else
/*
			if ( pFormatetc->cfFormat == RegisterClipboardFormat( CFSTR_PREFERREDDROPEFFECT ) )
			{

				n_memory_copy( &n_IDataObject_STGMEDIUM[ i ], pmedium, sizeof( STGMEDIUM ) );
				return S_OK;

			}

			if ( pFormatetc->cfFormat == RegisterClipboardFormat( CFSTR_PERFORMEDDROPEFFECT ) )
			{

				n_memory_copy( &n_IDataObject_STGMEDIUM[ i ], pmedium, sizeof( STGMEDIUM ) );
				return S_OK;

			}
*/

		}


		i++;
		if ( i >= n_IDataObject_support ) { break; }
	}


	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDataObject_GetDataHere( void *_this, FORMATETC *pFormatetc, STGMEDIUM *pmedium )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDataObject_QueryGetData( void *_this, FORMATETC *pFormatetc )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDataObject_GetCanonicalFormatEtc( void *_this, FORMATETC *pFormatetcIn, FORMATETC *pFormatetcOut )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDataObject_SetData( void *_this, FORMATETC *pFormatetc, STGMEDIUM *pmedium, BOOL fRelease )
{

//n_win_com_debug_cf2string( pFormatetc->cfFormat );


	if ( pFormatetc->lindex != -1 )
	{
		return DV_E_LINDEX;
	} else
	if ( pFormatetc->tymed != TYMED_HGLOBAL )
	{
		return DV_E_TYMED;
	} else
	if ( pFormatetc->dwAspect != DVASPECT_CONTENT )
	{
		return DV_E_DVASPECT;
	}


	size_t i = 0;
	while( 1 )
	{

		if ( pFormatetc->cfFormat == CF_HDROP )
		{

			n_memory_copy( pFormatetc, &n_IDataObject_FORMATETC[ 0 ], sizeof( FORMATETC ) );
			n_memory_copy( pmedium,    &n_IDataObject_STGMEDIUM[ 0 ], sizeof( STGMEDIUM ) );

			return S_OK;

		}// else
/*
		if ( pFormatetc->cfFormat == RegisterClipboardFormat( CFSTR_PREFERREDDROPEFFECT ) )
		{

			n_memory_copy( pFormatetc, &n_IDataObject_FORMATETC[ 1 ], sizeof( FORMATETC ) );
			n_memory_copy( pmedium,    &n_IDataObject_STGMEDIUM[ 1 ], sizeof( STGMEDIUM ) );

			return S_OK;

		} else
		if ( pFormatetc->cfFormat == RegisterClipboardFormat( CFSTR_PERFORMEDDROPEFFECT ) )
		{

			n_memory_copy( pFormatetc, &n_IDataObject_FORMATETC[ 2 ], sizeof( FORMATETC ) );
			n_memory_copy( pmedium,    &n_IDataObject_STGMEDIUM[ 2 ], sizeof( STGMEDIUM ) );

			return S_OK;

		}
*/


		i++;
		if ( i >= n_IDataObject_support ) { break; }
	}


	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDataObject_EnumFormatEtc( void *_this, DWORD dwDirection, IEnumFORMATETC **ppenumFormatetc )
{

	// dwDirection
	//
	//	typedef enum tagDATADIR
	//	{
	//		DATADIR_GET = 1,
	//		DATADIR_SET = 2,
	//	} DATADIR;

/*
	if ( dwDirection == DATADIR_GET )
	{
		n_posix_debug_literal( "IDataObject_EnumFormatEtc() : DATADIR_GET" );
	} else {
		n_posix_debug_literal( "IDataObject_EnumFormatEtc() : DATADIR_SET" );
	}
*/

	// [!] : crash when dropping to some applications
/*
	if ( n_IDataObject_is_dnd == false )
	{

		// OleSetClipboard() needs this interface

		(*ppenumFormatetc) = &n_IEnumFORMATETC_instance;

		return S_OK;

	}
*/

	return OLE_S_USEREG;
}

HRESULT __stdcall
n_IDataObject_DAdvise( void *_this, FORMATETC *pFormatetc, DWORD advf, IAdviseSink *pAdvSink, DWORD *pdwConnection )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDataObject_DUnadvise( void *_this, DWORD dwConnection )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IDataObject_EnumDAdvise( void *_this, IEnumSTATDATA **ppenumAdvise )
{
	return E_NOTIMPL;
}




const void *n_IDataObject_Vtbl[] = {

	n_IDataObject_QueryInterface,
	n_IDataObject_AddRef,
	n_IDataObject_Release,

	n_IDataObject_GetData,
	n_IDataObject_GetDataHere,
	n_IDataObject_QueryGetData,
	n_IDataObject_GetCanonicalFormatEtc,
	n_IDataObject_SetData,
	n_IDataObject_EnumFormatEtc,
	n_IDataObject_DAdvise,
	n_IDataObject_DUnadvise,
	n_IDataObject_EnumDAdvise,

};


static IDataObject n_IDataObject_instance = { (void*) n_IDataObject_Vtbl };




void
n_IDataObject_init( IDataObject **pp_IDataObject, const n_posix_char *path, size_t path_cch )
{

	if ( pp_IDataObject == NULL ) { return; } else { (*pp_IDataObject) = NULL; }


	n_IDataObject_counter = 1;
	(*pp_IDataObject)     = &n_IDataObject_instance;

	{

		UINT  cf = CF_HDROP;


		FORMATETC fe = { cf, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL  };
		STGMEDIUM sm = { TYMED_HGLOBAL, { NULL }, NULL };


		DROPFILES df = { sizeof( DROPFILES ), { 0,0 }, false, false };


		//n_IDataObject_cursor_set( &df );


#ifdef UNICODE
		df.fWide = true;
#else // #ifdef UNICODE
		df.fWide = false;
#endif // #ifdef UNICODE


		u32 path_cb = path_cch * sizeof( n_posix_char );


		sm.tymed          = TYMED_HGLOBAL;
		sm.hGlobal        = GlobalAlloc( GHND, sizeof( DROPFILES ) + path_cb );
		sm.pUnkForRelease = NULL;


		u8 *p = GlobalLock( sm.hGlobal );

		n_memory_copy( &df, p, sizeof( DROPFILES ) );
		n_memory_copy( path, (void*) &p[ sizeof( DROPFILES ) ], path_cb );

		GlobalUnlock( sm.hGlobal );


		n_IDataObject_SetData( &n_IDataObject_instance, &fe, &sm, false );

	}

/*
	{

		UINT  cf = RegisterClipboardFormat( CFSTR_PREFERREDDROPEFFECT );
		DWORD dw = DROPEFFECT_COPY;


		FORMATETC fe = { cf, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL  };
		STGMEDIUM sm = { TYMED_HGLOBAL, { NULL }, NULL };


		sm.hGlobal = GlobalAlloc( GPTR, sizeof( DWORD ) );


		u8 *p = GlobalLock( sm.hGlobal );

		n_memory_copy( &dw, p, sizeof( DWORD ) );

		GlobalUnlock( sm.hGlobal );


		n_IDataObject_SetData( &n_IDataObject_instance, &fe, &sm, false );

	}


	{

		UINT  cf = RegisterClipboardFormat( CFSTR_PERFORMEDDROPEFFECT );
		DWORD dw = DROPEFFECT_COPY;


		FORMATETC fe = { cf, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL  };
		STGMEDIUM sm = { TYMED_HGLOBAL, { NULL }, NULL };


		sm.hGlobal = GlobalAlloc( GPTR, sizeof( DWORD ) );


		u8 *p = GlobalLock( sm.hGlobal );

		n_memory_copy( &dw, p, sizeof( DWORD ) );

		GlobalUnlock( sm.hGlobal );


		n_IDataObject_SetData( &n_IDataObject_instance, &fe, &sm, false );

	}
*/


	return;
}

void
n_IDataObject_exit( IDataObject **pp_IDataObject )
{

	if ( pp_IDataObject == NULL ) { return; }


	if ( n_IDataObject_counter == 0 )
	{

		// [!] : Main

		if ( (*pp_IDataObject) != NULL )
		{
			(*pp_IDataObject)->lpVtbl->Release( (*pp_IDataObject) );
		}

	} else {

		// [!] : Fallback

		size_t i = 0;
		while ( 1 )
		{

			GlobalFree( n_IDataObject_STGMEDIUM[ i ].hGlobal );

			i++;
			if ( i >= n_IDataObject_support ) { break; }
		}

	}

	n_IDataObject_counter = 0;
	(*pp_IDataObject)     = NULL;

	n_memory_zero( n_IDataObject_FORMATETC, sizeof( FORMATETC ) * n_IDataObject_support );
	n_memory_zero( n_IDataObject_STGMEDIUM, sizeof( STGMEDIUM ) * n_IDataObject_support );


	return;
}

void
n_IDataObject_dnd_init( IDataObject **pp_IDataObject, const n_posix_char *path, size_t path_cch )
{

	n_IDataObject_is_dnd = true;

	n_IDataObject_init( pp_IDataObject, path, path_cch );


	return;
}

void
n_IDataObject_dnd_exit( IDataObject **pp_IDataObject )
{

	n_IDataObject_exit( pp_IDataObject );

	n_IDataObject_is_dnd = false;


	return;
}


#endif // _H_NONNON_WIN32_OLE_IDATAOBJECT

